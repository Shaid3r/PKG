
#include <App.h>

int main() {
    App::GetApp().run();

    return 0;
}